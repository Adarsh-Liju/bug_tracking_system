print("Abhay is nice")
