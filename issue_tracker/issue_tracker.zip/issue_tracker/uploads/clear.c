#include <termios.h>
#include <unistd.h>
#include <stdio.h>
int main()
{
    prin
    fflush(0);
}