#include <stdio.h>
main()
{
}

